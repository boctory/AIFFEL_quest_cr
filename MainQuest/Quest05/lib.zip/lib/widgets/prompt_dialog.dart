import 'package:flutter/material.dart';
import '../screens/generation_screen.dart';

class PromptDialog extends StatefulWidget {
  final String language;

  const PromptDialog({
    Key? key,
    required this.language,
  }) : super(key: key);

  @override
  State<PromptDialog> createState() => _PromptDialogState();
}

class _PromptDialogState extends State<PromptDialog> {
  final TextEditingController _promptController = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _promptController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isKorean = widget.language == '한국어';
    
    return AlertDialog(
      title: Text(isKorean ? '프롬프트 입력' : 'Enter your prompt'),
      content: TextField(
        controller: _promptController,
        focusNode: _focusNode,
        autofocus: true,
        textInputAction: TextInputAction.go,
        onSubmitted: (_) => _generateImage(context),
        decoration: InputDecoration(
          hintText: isKorean 
              ? '생성하고 싶은 이미지를 설명해주세요...'
              : 'Describe the image you want to generate...',
          border: const OutlineInputBorder(),
          contentPadding: const EdgeInsets.all(16),
        ),
        maxLines: 3,
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(isKorean ? '취소' : 'Cancel'),
        ),
        ElevatedButton(
          onPressed: () => _generateImage(context),
          child: Text(isKorean ? '생성하기' : 'Generate'),
        ),
      ],
    );
  }

  void _generateImage(BuildContext context) {
    if (_promptController.text.trim().isNotEmpty) {
      Navigator.pop(context);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => GenerationScreen(
            prompt: _promptController.text,
          ),
        ),
      );
    }
  }
} 