import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class StableDiffusionService {
  static const String baseUrl = 'https://api.stability.ai';
  static const String apiKey = 'sk-PM2g5V7UM7BOTgq7NyxDBu6CfnlNqrYUxQN1cNY8mcXcloS3';

  Future<String> generateImage(String prompt) async {
    if (prompt.trim().isEmpty) {
      throw Exception('Prompt cannot be empty');
    }

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/v1/generation/stable-diffusion-v1-6/text-to-image'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $apiKey',
        },
        body: jsonEncode({
          'text_prompts': [
            {
              'text': prompt,
              'weight': 1.0
            }
          ],
          'cfg_scale': 7.0,
          'height': 512,
          'width': 512,
          'samples': 1,
          'steps': 30,
          'style_preset': 'digital-art',
          'engine': 'stable-diffusion-v1-6',
        }),
      );

      if (response.statusCode == 200) {
        if (kDebugMode) {
          print('Response body: ${response.body}');
        }
        final data = jsonDecode(response.body);
        final images = data['artifacts'] as List;
        if (images.isNotEmpty) {
          return images[0]['base64'];
        }
      } else {
        if (kDebugMode) {
          print('Error response: ${response.body}');
        }
        throw Exception('Failed to generate image: ${response.statusCode} - ${response.body}');
      }
      throw Exception('No image generated');
    } catch (e) {
      if (kDebugMode) {
        print('Error generating image: $e');
      }
      throw Exception('Failed to generate image: $e');
    }
  }
} 