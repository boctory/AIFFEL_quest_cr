import 'package:google_generative_ai/google_generative_ai.dart';

class GeminiService {
  static const String apiKey = 'YOUR_GEMINI_API_KEY';
  late final GenerativeModel _model;

  GeminiService() {
    _model = GenerativeModel(
      model: 'gemini-pro-vision',
      apiKey: apiKey,
    );
  }

  Future<String> generateImage(String prompt, String style) async {
    try {
      final content = Content.text('Generate an image of $prompt in $style style');
      final response = await _model.generateContent([content]);
      return response.text ?? 'Failed to generate image';
    } catch (e) {
      throw Exception('Failed to generate image: $e');
    }
  }
} 