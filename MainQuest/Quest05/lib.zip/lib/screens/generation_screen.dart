import 'package:flutter/material.dart';
import 'result_screen.dart';
import '../services/stable_diffusion_service.dart';

class GenerationScreen extends StatefulWidget {
  final String prompt;

  const GenerationScreen({Key? key, required this.prompt}) : super(key: key);

  @override
  State<GenerationScreen> createState() => _GenerationScreenState();
}

class _GenerationScreenState extends State<GenerationScreen> {
  final StableDiffusionService _service = StableDiffusionService();
  String? _imageUrl;
  String? _error;

  @override
  void initState() {
    super.initState();
    _generateImage();
  }

  Future<void> _generateImage() async {
    try {
      setState(() {
        _error = null;
      });

      final imageUrl = await _service.generateImage(widget.prompt);
      
      setState(() {
        _imageUrl = imageUrl;
      });

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ResultScreen(
              imageUrl: _imageUrl!,
              language: widget.prompt,
            ),
          ),
        );
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _error != null
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Error: $_error'),
                  ElevatedButton(
                    onPressed: _generateImage,
                    child: const Text('Retry'),
                  ),
                ],
              )
            : const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 20),
                  Text('Generating your art...'),
                ],
              ),
      ),
    );
  }
} 