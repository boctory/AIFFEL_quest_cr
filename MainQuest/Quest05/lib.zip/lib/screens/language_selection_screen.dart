import 'package:flutter/material.dart';
import '../widgets/prompt_dialog.dart';

class LanguageSelectionScreen extends StatefulWidget {
  const LanguageSelectionScreen({super.key});

  @override
  State<LanguageSelectionScreen> createState() => _LanguageSelectionScreenState();
}

class _LanguageSelectionScreenState extends State<LanguageSelectionScreen> {
  String? _selectedLanguage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_selectedLanguage == '한국어' ? '언어 선택' : 'Choose Your Language'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 40),
            Wrap(
              spacing: 16,
              runSpacing: 16,
              alignment: WrapAlignment.center,
              children: [
                _LanguageButton(
                  flag: '🇺🇸',
                  language: 'English (US)',
                  isSelected: _selectedLanguage == 'English (US)',
                  onTap: () => _selectLanguage('English (US)'),
                ),
                _LanguageButton(
                  flag: '🇬🇧',
                  language: 'English',
                  isSelected: _selectedLanguage == 'English',
                  onTap: () => _selectLanguage('English'),
                ),
                _LanguageButton(
                  flag: '🇰🇷',
                  language: '한국어',
                  isSelected: _selectedLanguage == '한국어',
                  onTap: () => _selectLanguage('한국어'),
                ),
                _LanguageButton(
                  flag: '🇪🇸',
                  language: 'Español',
                  isSelected: _selectedLanguage == 'Español',
                  onTap: () => _selectLanguage('Español'),
                ),
              ],
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: _selectedLanguage != null 
                  ? () => _navigateToGeneration(context)
                  : null,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(_selectedLanguage == '한국어' ? '계속하기' : 'Continue'),
            ),
          ],
        ),
      ),
    );
  }

  void _selectLanguage(String language) {
    setState(() {
      _selectedLanguage = language;
    });
  }

  void _navigateToGeneration(BuildContext context) {
    if (_selectedLanguage != null) {
      showDialog(
        context: context,
        builder: (context) => PromptDialog(
          language: _selectedLanguage!,
        ),
      );
    }
  }
}

class _LanguageButton extends StatelessWidget {
  final String flag;
  final String language;
  final VoidCallback onTap;
  final bool isSelected;

  const _LanguageButton({
    required this.flag,
    required this.language,
    required this.onTap,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 140,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white24),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(flag, style: const TextStyle(fontSize: 32)),
            const SizedBox(height: 8),
            Text(language),
          ],
        ),
      ),
    );
  }
} 