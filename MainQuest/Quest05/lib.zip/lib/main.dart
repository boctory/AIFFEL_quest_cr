import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/splash_screen.dart';
import 'package:flutter/foundation.dart';

void main() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();
    // Set preferred orientations
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    
    runApp(const MyApp());
  } catch (e) {
    if (kDebugMode) {
      print('Error initializing app: $e');
    }
    rethrow;
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Astory',
      debugShowCheckedModeBanner: false,  // Removes debug banner
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        primaryColor: const Color(0xFF1A237E),
        scaffoldBackgroundColor: const Color(0xFF0A1128),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF4A5BF6),
          secondary: Color(0xFF7C4DFF),
        ),
      ),
      home: const SplashScreen(),
    );
  }
} 