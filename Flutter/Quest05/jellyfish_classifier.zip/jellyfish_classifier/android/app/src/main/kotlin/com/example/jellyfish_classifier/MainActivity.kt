package com.example.jellyfish_classifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
